<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); 

function SyspatBuildRoute(&$query)
{
	$segments = array();
	return $segments;
}

function SyspatParseRoute($segments) 
{

}