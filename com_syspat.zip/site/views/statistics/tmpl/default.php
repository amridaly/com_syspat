<div class="row-fluid">
    <aside>
        <div id="sidebar"  class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu">                
            <li class="sidebar-menu active">
                <a class="" href="calender.php">
                    <i class="icon_house_alt"></i>
                    <span>Accueil</span>
                </a>
            </li>


            <li class="sidebar-menu ">                     
                <a href="charts.php" class="">
                    <i class="icon_piechart"></i>
                    <span>Statistiques</span>
                </a>
            </li>

            <li class="sidebar-menu">                     
                <a href="actions.php" class="">
                    <i class="icon_table"></i>
                    <span>Actions/Activités</span>
                </a>
            </li>

            <li class="sidebar-menu">                     
                <a href="evaluations.php" class="">
                    <i class="icon_table"></i>
                    <span>Evaluations</span>
                </a>
            </li>
        </ul>
        <!-- sidebar menu end-->
    </div>
    </aside>

    <section id="main-content">
        <section class="wrapper">            
            <!-- calender & widgets start -->
            <div class="row">
                <section class="panel">
                    <div class="panel-body">
                        <div id="calendar" class="has-toolbar"></div>
                    </div>
                </section>
            </div>
            <!-- calender & widgets end -->
        </section>
    </section>
</div>
