<?php defined( '_JEXEC' ) or die( 'Restricted access' ); 
 
class SyspatViewsCalendarHtml extends JViewHtml
{
  function render()
  {
    $app = JFactory::getApplication();
  
    //display
    return parent::render();
  } 
  
 

}