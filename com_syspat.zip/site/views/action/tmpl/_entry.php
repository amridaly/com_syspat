<tr>
  <td><?php echo $this->action->DOMAIN_LABEL; ?></td>
  <td><?php echo $this->action->DESCRIPTION; ?></td>
  <td><?php echo $this->action->START_DATE; ?></td>
  <td><?php echo $this->action->DUE_DATE; ?></td>
  <td><?php echo $this->action->STRUCTURE_LABEL; ?></td>
</tr>