DROP view ws_syspat_action_activ;
DROP view ws_syspat_action_activ_has_indic_pefa;
DROP view ws_syspat_act_periods;
DROP view ws_syspat_eval_action_activ;
DROP view ws_syspat_eval_act_indic_pefa;
DROP view ws_syspat_indicator_pefa;
DROP view ws_syspat_actions;





